@echo off
title IP Tracker
python ip_tracker.py
if errorlevel 1 (
    echo.
    echo Could not start the program. Make sure Python is installed.
    pause
)
