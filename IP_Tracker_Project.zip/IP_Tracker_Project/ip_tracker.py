import tkinter as tk
from tkinter import messagebox, filedialog
import ipaddress
import json
import urllib.request
import urllib.error
import webbrowser
from datetime import datetime

API_URL = "https://ipwho.is/{}"

class IPTrackerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("IP Tracker | OSINT Tool")
        self.root.geometry("820x650")
        self.root.minsize(720, 580)
        self.root.configure(bg="#101827")
        self.data = None

        tk.Label(root, text="IP TRACKER", font=("Segoe UI", 25, "bold"),
                 fg="#f3f6fb", bg="#101827").pack(pady=(22, 2))
        tk.Label(root, text="Public IP information lookup",
                 font=("Segoe UI", 11), fg="#9eacc0", bg="#101827").pack(pady=(0, 18))

        search = tk.Frame(root, bg="#1b293b", padx=18, pady=18)
        search.pack(fill="x", padx=28)
        tk.Label(search, text="Enter an IP address", font=("Segoe UI", 10, "bold"),
                 fg="#e8eef7", bg="#1b293b").pack(anchor="w")
        line = tk.Frame(search, bg="#1b293b")
        line.pack(fill="x", pady=(8, 0))
        self.ip_entry = tk.Entry(line, font=("Segoe UI", 12), bg="#f4f7fb",
                                 fg="#172033", relief="flat")
        self.ip_entry.pack(side="left", fill="x", expand=True, ipady=10, padx=(0, 10))
        self.ip_entry.bind("<Return>", lambda event: self.lookup())
        tk.Button(line, text="SEARCH", command=self.lookup, font=("Segoe UI", 10, "bold"),
                  bg="#2878e5", fg="white", activebackground="#1f65c4",
                  activeforeground="white", relief="flat", padx=22, pady=10,
                  cursor="hand2").pack(side="left")

        self.status = tk.Label(root, text="Enter a public IP address to begin.",
                               font=("Segoe UI", 9), fg="#aab8ca", bg="#101827")
        self.status.pack(anchor="w", padx=32, pady=(12, 8))

        results = tk.Frame(root, bg="#1b293b", padx=20, pady=16)
        results.pack(fill="both", expand=True, padx=28, pady=(0, 16))
        tk.Label(results, text="LOOKUP RESULTS", font=("Segoe UI", 10, "bold"),
                 fg="#75b4ff", bg="#1b293b").pack(anchor="w", pady=(0, 10))

        self.fields = {}
        rows = [
            ("IP Address", "ip"), ("IP Version", "version"),
            ("Country", "country"), ("City", "city"),
            ("Region", "region"), ("Postal Code", "postal"),
            ("ISP", "isp"), ("Organization", "org"),
            ("Latitude", "latitude"), ("Longitude", "longitude"),
            ("Timezone", "timezone")
        ]
        grid = tk.Frame(results, bg="#1b293b")
        grid.pack(fill="both", expand=True)
        for index, (label, key) in enumerate(rows):
            row, col = divmod(index, 2)
            cell = tk.Frame(grid, bg="#223249", padx=12, pady=8)
            cell.grid(row=row, column=col, sticky="nsew", padx=5, pady=5)
            tk.Label(cell, text=label.upper(), font=("Segoe UI", 8, "bold"),
                     fg="#9eacc0", bg="#223249").pack(anchor="w")
            value = tk.Label(cell, text="—", font=("Segoe UI", 10),
                             fg="#f3f6fb", bg="#223249", anchor="w")
            value.pack(anchor="w", pady=(3, 0), fill="x")
            self.fields[key] = value
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)

        buttons = tk.Frame(root, bg="#101827")
        buttons.pack(pady=(0, 20))
        self.map_button = tk.Button(buttons, text="OPEN LOCATION MAP",
                                    command=self.open_map, state="disabled",
                                    font=("Segoe UI", 9, "bold"), bg="#16866b",
                                    fg="white", relief="flat", padx=16, pady=9,
                                    cursor="hand2")
        self.map_button.pack(side="left", padx=5)
        self.save_button = tk.Button(buttons, text="EXPORT REPORT",
                                     command=self.export_report, state="disabled",
                                     font=("Segoe UI", 9, "bold"), bg="#46566d",
                                     fg="white", relief="flat", padx=16, pady=9,
                                     cursor="hand2")
        self.save_button.pack(side="left", padx=5)
        tk.Label(root, text="Educational OSINT tool • IP location is approximate",
                 font=("Segoe UI", 8), fg="#718096", bg="#101827").pack(pady=(0, 10))

    def lookup(self):
        raw_ip = self.ip_entry.get().strip()
        if not raw_ip:
            messagebox.showwarning("Missing IP", "Please enter an IP address.")
            return
        try:
            parsed = ipaddress.ip_address(raw_ip)
        except ValueError:
            messagebox.showerror("Invalid IP", "Please enter a valid IPv4 or IPv6 address.")
            return
        if not parsed.is_global:
            messagebox.showwarning(
                "Public IP required",
                "This lookup uses public IP geolocation. Private, local, and reserved IP addresses cannot be located by this service."
            )
            return

        self.status.config(text="Searching public IP information...", fg="#f2c46d")
        self.root.update_idletasks()
        try:
            request = urllib.request.Request(
                API_URL.format(raw_ip),
                headers={"User-Agent": "IPTrackerEducationalProject/1.0"}
            )
            with urllib.request.urlopen(request, timeout=15) as response:
                result = json.loads(response.read().decode("utf-8"))
            if not result.get("success", False):
                raise ValueError(result.get("message", "The IP lookup service could not find information."))
            self.data = result
            connection = result.get("connection") or {}
            timezone = result.get("timezone") or {}
            values = {
                "ip": result.get("ip", raw_ip),
                "version": result.get("type", "—"),
                "country": result.get("country", "—"),
                "city": result.get("city", "—"),
                "region": result.get("region", "—"),
                "postal": result.get("postal", "—"),
                "isp": connection.get("isp", "—"),
                "org": connection.get("org", "—"),
                "latitude": result.get("latitude", "—"),
                "longitude": result.get("longitude", "—"),
                "timezone": timezone.get("id", "—")
            }
            for key, value in values.items():
                self.fields[key].config(text=str(value) if value not in (None, "") else "—")
            self.status.config(text="Lookup completed successfully.", fg="#72d6a4")
            self.map_button.config(state="normal")
            self.save_button.config(state="normal")
        except urllib.error.URLError:
            self.status.config(text="Connection failed.", fg="#ff9b9b")
            messagebox.showerror("Connection Error", "Could not reach the IP information service. Check your internet connection and try again.")
        except (TimeoutError, ValueError, json.JSONDecodeError) as error:
            self.status.config(text="Lookup could not be completed.", fg="#ff9b9b")
            messagebox.showerror("Lookup Error", str(error))
        except Exception as error:
            self.status.config(text="An unexpected error occurred.", fg="#ff9b9b")
            messagebox.showerror("Error", str(error))

    def open_map(self):
        if not self.data:
            return
        lat = self.data.get("latitude")
        lon = self.data.get("longitude")
        if lat is None or lon is None:
            messagebox.showinfo("Map unavailable", "Coordinates were not provided for this IP.")
            return
        webbrowser.open(f"https://www.google.com/maps?q={lat},{lon}")

    def export_report(self):
        if not self.data:
            return
        connection = self.data.get("connection") or {}
        timezone = self.data.get("timezone") or {}
        report = [
            "IP TRACKER - OSINT LOOKUP REPORT",
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            f"IP Address: {self.data.get('ip', '—')}",
            f"IP Version: {self.data.get('type', '—')}",
            f"Country: {self.data.get('country', '—')}",
            f"City: {self.data.get('city', '—')}",
            f"Region: {self.data.get('region', '—')}",
            f"Postal Code: {self.data.get('postal', '—')}",
            f"ISP: {connection.get('isp', '—')}",
            f"Organization: {connection.get('org', '—')}",
            f"Latitude: {self.data.get('latitude', '—')}",
            f"Longitude: {self.data.get('longitude', '—')}",
            f"Timezone: {timezone.get('id', '—')}",
            "",
            "Note: IP geolocation is approximate. It does not identify a person's exact physical location."
        ]
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt")],
            initialfile="IP_Tracker_Report.txt"
        )
        if path:
            with open(path, "w", encoding="utf-8") as file:
                file.write("\n".join(report))
            messagebox.showinfo("Saved", "Report exported successfully.")

if __name__ == "__main__":
    root = tk.Tk()
    app = IPTrackerApp(root)
    root.mainloop()
