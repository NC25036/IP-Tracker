IP TRACKER - WINDOWS PROJECT

FEATURES
1. IP Lookup: retrieves publicly available information about an IP address.
2. Country and City Detection: displays the approximate country, city and region.
Also displays ISP, IP version, coordinates and timezone when available.
Includes an Open Location Map button and TXT report export.

REQUIREMENTS
- Windows 10 or Windows 11
- Python 3 installed from https://www.python.org/downloads/
- Internet connection
- No extra Python packages are required. The project uses Python's standard library.

HOW TO RUN
1. Extract IP_Tracker_Project.zip.
2. Open the extracted IP_Tracker_Project folder.
3. Double-click run_ip_tracker.bat.
   OR open Command Prompt in this folder and run:
       python ip_tracker.py
4. Enter a public IP address, for example 8.8.8.8, then click SEARCH.
5. Click OPEN LOCATION MAP to view the approximate coordinates in Google Maps.
6. Click EXPORT REPORT to save the results as a TXT file.

IMPORTANT
- The tool uses the public IP information service at https://ipwho.is/.
- An internet connection is required.
- Public IP geolocation is approximate. It does not reveal a person's exact physical location.
- Private/local IP addresses (such as 192.168.x.x) cannot be geolocated by this public service.
- Use the tool for educational purposes and authorized network research.
